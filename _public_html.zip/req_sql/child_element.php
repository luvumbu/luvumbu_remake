<?php 
require_once "require_once.php" ;
$date_inscription_projet = date("Y-m-d H:i:s");
$_SESSION["index"][4] = $_POST["child_element"] ; 
?>
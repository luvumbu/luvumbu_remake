<script>
    // Déclaration de variables contenant des URLs d'icônes
    const visible_1 = "<?= $visible_1 ?>";
    const visible_2 = "<?= $visible_2 ?>";
    // Script exécuté une fois que la page est entièrement chargée
    window.onload = function() {
        document.getElementById("body").className = ""; // Suppression de la classe initiale du body
    };
</script>
<?php
require_once $home_select_all_sql_1;
require_once $home_select_all_css;
require_once $home_select_all_js;
?>
<div class="div_elements" style="margin-top:150px">
  <?php
  require_once "data/all/all_select_all.php";
  ?>

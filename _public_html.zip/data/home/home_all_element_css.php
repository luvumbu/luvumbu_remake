 <style>
    .card_img {
        width: 250px;
        max-height: 100px;
        overflow-y: hidden;
        /* Hide vertical scrollbar */
    }

    .card_img img {
        width: 100%;
    }
    .element{
        max-width: 100%;
        overflow-x: hidden;
    }
    .parent_element {
        border: 1px solid rgba(0, 0, 0, 0.1);
        text-align: center;
        width: 250px;
        margin: 45px;
    }
    .element {
        padding: 15px;
    }
    .display_flex_ {
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
    }
</style>
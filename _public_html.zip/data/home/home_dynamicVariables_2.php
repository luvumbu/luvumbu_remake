 <?php 
$change_meta_name_projet_dynamic_1_ =  $change_meta_name_projet_dynamic_1[$i];
$change_meta_content_projet_dynamic_1_ = $change_meta_content_projet_dynamic_1[$i];
$id_sha1_projet_dynamic_1_ = $id_sha1_projet_dynamic_1[$i];
$description_projet_dynamic_1_ = $description_projet_dynamic_1[$i];
$title_projet_dynamic_1_ =     $title_projet_dynamic_1[$i];
$html_mode_projet_1_dynamic_1_ = $html_mode_projet_1_dynamic_1[$i];
$html_mode_projet_2_dynamic_1_ = $html_mode_projet_2_dynamic_1[$i];
$google_title_projet_dynamic_1_ =  AsciiConverter::asciiToString($google_title_projet_dynamic_1[$i]); // Affiche "Hello"
$change_meta_name_projet_dynamic_1__ =  AsciiConverter::asciiToString($change_meta_name_projet_dynamic_1_); // Affiche "Hello"
$change_meta_content_projet_dynamic_1__ =  AsciiConverter::asciiToString($change_meta_content_projet_dynamic_1_);
?>
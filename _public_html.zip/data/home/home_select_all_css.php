 <style>
    .cursor_pointer:hover{
      cursor: pointer;
    }
    .card_element {
      border: 1px solid rgba(0, 0, 0, 0.2);
      width: 300px;
      margin: auto;
      margin-right: 150px;
      margin-bottom: 150px;
    }
    .card_element_img img {
      width: 100%;
    }
    .card_element_title {
      text-align: center;
      padding: 10px;
    }
    .div_elements {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
    }
    #add_projet {
      display: none;
    }
  </style>

 
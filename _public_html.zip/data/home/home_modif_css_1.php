<style>
  body {
    font-family: Arial, sans-serif;
    margin: 20px;
  }

  .editor-container {
    margin-bottom: 40px;
    border: 1px solid #ccc;
    padding: 20px;
    border-radius: 8px;
  }

  .toolbar {
    margin-bottom: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }

  input[type="color"],
  select,
  button {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
  }

  .textInput {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
    min-height: 200px;
    outline: none;
    background: #fff;
  }

  button {
    background-color: #f0f0f0;
    cursor: pointer;
  }

  button:hover {
    background-color: #ddd;
  }

  .largeur_juste {

    width: 80%;
    margin: auto;
    background-color: #fff;
    margin-bottom: 25px;
  }



  .grande_image {
    width: 300px;
    margin: auto;
    margin-top: 25px;
    margin-bottom: 25px;

  }

  .grande_image img {
    width: 100%;
    box-shadow: 1px 1px 7px black;
    transition: 1s all;
  }

  .grande_image img:hover {
    width: 100%;
    box-shadow: 1px 1px 17px black;
    transition: 1s all;
    cursor: pointer;
  }

  .display_flex1 {
    display: flex;
    justify-content: space-around;

  }

  .display_flex1 {
    margin-top: 50px;
    margin-bottom: 50px;

  }

  .display_flex1 div:hover {
    cursor: pointer;
  }
</style>
<?php
$row_projet_img = 
array(
    array(
        "id_projet_img_auto" => "1",
        "id_general" => "1746192302x40",
        "id_sha1_projet_img" => "1746191860",
        "id_projet_img" => "uploads/1746191860_1746192298.png",
        "id_user_projet_img" => "1746188185",
        "img_projet_src_img" => "1746191860_1746192298",
        "extention_img" => ".png",
        "date_inscription_projet_img" => "2025-05-02 15:25:02",
    ),
);
?>
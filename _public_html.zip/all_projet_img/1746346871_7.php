<?php
$row_projet_img = 
array(
    array(
        "id_projet_img_auto" => "9",
        "id_general" => "1746352099x77",
        "id_sha1_projet_img" => "1746346871_7",
        "id_projet_img" => "uploads/1746346871_7_1746352092.jpg",
        "id_user_projet_img" => "1746271395",
        "img_projet_src_img" => "1746346871_7_1746352092",
        "extention_img" => ".jpg",
        "date_inscription_projet_img" => "2025-05-04 09:48:19",
    ),
);
?>
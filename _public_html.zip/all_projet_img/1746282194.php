<?php
$row_projet_img = 
array(
    array(
        "id_projet_img_auto" => "1",
        "id_general" => "1746282211x20",
        "id_sha1_projet_img" => "1746282194",
        "id_projet_img" => "uploads/1746282194_1746282208.png",
        "id_user_projet_img" => "1746245776",
        "img_projet_src_img" => "1746282194_1746282208",
        "extention_img" => ".png",
        "date_inscription_projet_img" => "2025-05-03 16:23:31",
    ),
);
?>
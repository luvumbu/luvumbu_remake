<?php
$row_projet_img = 
array(
    array(
        "id_projet_img_auto" => "2",
        "id_general" => "1746132929x72",
        "id_sha1_projet_img" => "1746109932",
        "id_projet_img" => "uploads/1746109932_1746132925.png",
        "id_user_projet_img" => "1746109919",
        "img_projet_src_img" => "1746109932_1746132925",
        "extention_img" => ".png",
        "date_inscription_projet_img" => "2025-05-01 22:55:29",
    ),
    array(
        "id_projet_img_auto" => "3",
        "id_general" => "1746132944x13",
        "id_sha1_projet_img" => "1746109932",
        "id_projet_img" => "uploads/1746109932_1746132941.png",
        "id_user_projet_img" => "1746109919",
        "img_projet_src_img" => "1746109932_1746132941",
        "extention_img" => ".png",
        "date_inscription_projet_img" => "2025-05-01 22:55:44",
    ),
    array(
        "id_projet_img_auto" => "4",
        "id_general" => "1746132961x48",
        "id_sha1_projet_img" => "1746109932",
        "id_projet_img" => "uploads/1746109932_1746132955.png",
        "id_user_projet_img" => "1746109919",
        "img_projet_src_img" => "1746109932_1746132955",
        "extention_img" => ".png",
        "date_inscription_projet_img" => "2025-05-01 22:56:01",
    ),
);
?>
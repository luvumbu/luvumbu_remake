<?php
$row_projet_img = 
array(
    array(
        "id_projet_img_auto" => "1",
        "id_general" => "1746184031x18",
        "id_sha1_projet_img" => "1746181773",
        "id_projet_img" => "uploads/1746181773_1746184026.png",
        "id_user_projet_img" => "1746177978",
        "img_projet_src_img" => "1746181773_1746184026",
        "extention_img" => ".png",
        "date_inscription_projet_img" => "2025-05-02 13:07:11",
    ),
);
?>
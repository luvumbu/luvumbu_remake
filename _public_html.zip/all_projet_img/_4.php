<?php
$row_projet_img = 
array(
    array(
        "id_projet_img_auto" => "2",
        "id_general" => "1746327978x34",
        "id_sha1_projet_img" => "1746327960",
        "id_projet_img" => "uploads/1746327960_1746327973.png",
        "id_user_projet_img" => "1746245776",
        "img_projet_src_img" => "1746327960_1746327973",
        "extention_img" => ".png",
        "date_inscription_projet_img" => "2025-05-04 05:06:18",
    ),
);
?>
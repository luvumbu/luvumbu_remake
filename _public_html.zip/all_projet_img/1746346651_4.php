<?php
$row_projet_img = 
array(
    array(
        "id_projet_img_auto" => "8",
        "id_general" => "1746346673x92",
        "id_sha1_projet_img" => "1746346651_4",
        "id_projet_img" => "uploads/1746346651_4_1746346667.webp",
        "id_user_projet_img" => "1746271395",
        "img_projet_src_img" => "1746346651_4_1746346667",
        "extention_img" => ".webp",
        "date_inscription_projet_img" => "2025-05-04 08:17:53",
    ),
);
?>
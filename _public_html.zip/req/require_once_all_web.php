<?php 
require_once "Class/Give_url.php";
require_once "Class/DatabaseHandler.php";
require_once "Class/dbCheck.php";
require_once 'Class/AsciiConverter.php';
require_once "view/divHierarchy_array.php";
require_once "Class/extraireAlphabetique.php";
require_once "Class/nettoyerTexteHtml.php";
require_once "Class/Get_anne_2.php";
require_once "Class/Div_page.php";
?>
<?php 
session_start() ; 
$_SESSION["index"][4]= "" ; 
?>
<meta http-equiv="refresh" content="0; URL=../index.php">
# Logger

## Journalisation centralisée

### Méthodes :
```php
Logger::log(string $message): void
```

### Exemple :
```php
Logger::log('Démarrage module X');
```

### Format des logs :
`[YYYY-MM-DD HH:MM:SS] message`

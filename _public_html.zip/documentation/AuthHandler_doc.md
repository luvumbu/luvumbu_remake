# AuthHandler

## Authentification sécurisée

### Méthodes :
- `authenticate($user, $pass)`
- `getHash($username)`

### Dépendances :
- Logger
- DatabaseHandler

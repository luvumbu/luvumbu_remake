# calculateReadingTime

## Estimation temps de lecture

### Paramètres :
- Mots par minute (défaut: 250)
- Langue (ajustements automatiques)

Usage :
```php
$calculator = new ReadingTimeCalculator($text);
$minutes = $calculator->getMinutes();
```

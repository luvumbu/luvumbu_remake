# ConfigManager

## Gestion des configurations

### Usage :
```php
ConfigManager::load('config.ini');
$value = ConfigManager::get('section.key');
```

### Formats supportés :
- INI
- JSON (à venir)

<?php 

function removeHtmlTags($input){
    return strip_tags($input);
}

?>
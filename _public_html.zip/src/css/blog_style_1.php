<style>
    a {
        text-decoration: none;
    }

    body {
        font-family: "Tuffy", sans-serif;
        font-weight: 400;
        font-style: normal;
    }

    .blog_index_header_img {
        background-color: red;
        padding: 10px solid blue;
        width: 20%;
    }

    .blog_index_header_img_2 {
        transition: all 1s;
        width: 60%;
    }

    .card {
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        margin-bottom: 75px;
        text-align: center;
        width: 300px;
    }

    .card_img {
        height: 200px;
        overflow: hidden;
        width: 100%;
    }

    .card_img img {
        height: 100%;
        object-fit: cover;
        width: 100%;
    }

    .description_projet_ {
        height: 100px;
        overflow: hidden;
        padding: 7px;
        padding-bottom: 15px;
        text-align: justify;
    }

    .display_flex_element {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
    }

    .down,
    .exit,
    .up {
        background: #fff;
        border-radius: 50%;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        opacity: 0.5;
        padding: 5px;
        position: fixed;
        transition: all 0.3s ease;
        z-index: 1000;
    }

    .down {
        right: 20px;
        top: 55px;
    }

    .exit {
        bottom: 0px;
        left: 10px;
        opacity: 0.6;
        width: 20px;
    }

    .g_description_projet_2 {
        margin: 45px;
        text-align: justify;
    }

    .g_img_projet_src1 {
        margin: auto;
        width: 400px;
    }

    .g_img_projet_src1 img {
        width: 100%;
    }

    .g_title_projet_2 {
        font-size: 2em;
        margin: 50px;
        text-align: center;
    }

    html {
        scroll-behavior: smooth;
        scrollbar-color: black transparent;
        scrollbar-width: thin;
    }

    /* Scrollbar Chrome, Edge, Safari */
    ::-webkit-scrollbar {
        width: 6px;
    }

    ::-webkit-scrollbar-track {
        background: transparent;
    }

    ::-webkit-scrollbar-thumb {
        background-color: black;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background-color: #333;
    }

    .margin_autre {
        background-color: rgb(20, 7, 92);
        color: white;
        margin: 45px auto 45px auto;
        padding: 15px;
        text-align: center;
        width: 85%;
    }

    .margin_autre2 {
        background-color: rgb(20, 7, 92);
        color: white;
        margin: 0;
        padding-top: 10px;
        padding-bottom: 10px;
        width: 100%;
    }

    .slider-container {
        background: #222;
        border: 2px solid #fff;
        border-radius: 10px;
        margin: auto;
        margin-bottom: 45px;
        overflow: hidden;
        width: 70%;
    }

    .slider-track {
        animation: scroll 18s linear infinite;
        display: flex;
        width: max-content;
    }

    .slider-track img {
        border-radius: 8px;
        height: 500px;
        margin-right: 10px;
        object-fit: cover;
        width: 300px;
    }

    .title_projet_2 {
        padding: 10px;
    }

    .tuffy-bold {
        font-family: "Tuffy", sans-serif;
        font-style: normal;
        font-weight: 700;
    }

    .tuffy-bold-italic {
        font-family: "Tuffy", sans-serif;
        font-style: italic;
        font-weight: 700;
    }

    .tuffy-regular-italic {
        font-family: "Tuffy", sans-serif;
        font-style: italic;
        font-weight: 400;
    }

    .up {
        bottom: 55px;
        right: 20px;
    }

    /* Hover effects */
    .down:hover,
    .exit:hover,
    .up:hover {
        cursor: pointer;
        opacity: 1;
        transform: scale(1.1);
    }

    .exit:hover {
        opacity: 1;
    }

    @keyframes scroll {
        0% {
            transform: translateX(0);
        }
        100% {
            transform: translateX(-50%);
        }
    }

    @media screen and (max-width: 1200px) {
        .blog_index_header_img {
            background-color: red;
            padding: 10px solid blue;
            transition: all 1s;
            width: 80%;
        }

        .blog_index_header_img_2 {
            transition: all 1s;
            width: 70%;
        }
    }
</style>

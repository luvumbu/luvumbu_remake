<style>
    .audio_img {
        text-align: center;
        width: 80%;
        margin: auto;
    }

    .audio_img img {
        width: 100%;

    }

    .audio_bloc_texte {

        width: 80%;
        margin: auto;

        margin-top: 75px;
        margin-bottom: 75px;

    }

    .text-x {
        text-align: justify;
        margin-top: 75px;
        margin-bottom: 75px;

    }

    .audio_p_img {
        max-height: 300px;

        overflow-y: hidden;


    }

    .audio_p_img img {
        width: 100%;
        height: auto;

    }

    .audio_p_img {

        text-align: center;
    }

    .audio_display_flex {
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
        overflow-y: scroll;
 



    }
    .audio_display_flex div {
        width: 300px;
        
    }
















    .audio_description {
   
     height: 200px;
    overflow-y: scroll; /* Hide scrollbars */
    overflow-x:hidden; /* Hide scrollbars */

    text-align: justify;
    margin-top: 45px;
    margin-bottom: 45px;

    }

    .audio_child_projet_t {
        text-align: center;

        width: 100%;
        padding: 10px;
        margin: 0;
    }

    .audio_complet_a {
        padding: 10px;
        color: white;
        background-color: black;
        text-align: center;
    }
</style>
<style>
    .audio_img {
        text-align: center;
        width: 80%;
        margin: auto;
    }

    .audio_img img {
        width: 100%;

    }

    .audio_bloc_texte {

        width: 80%;
        margin: auto;

        margin-top: 75px;
        margin-bottom: 75px;

    }

    .text-x {
        text-align: justify;
        margin-top: 75px;
        margin-bottom: 75px;

    }

    .audio_p_img {
        max-height: 300px;

        overflow-y: hidden;


    }

    .audio_p_img img {
        width: 100%;
        height: auto;

    }

    .audio_p_img {

        text-align: center;
    }

    .audio_display_flex {
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
        overflow-y: scroll;

        max-height: 700px;
        margin-top: 60px;
        flex-wrap: wrap;


        margin: auto;
        margin-top: 175px;
        margin-bottom: 175px;
        border-bottom: 3px solid black;
        border-top: 3px solid black;


    }

    .audio_display_flex div {

        margin: 0;
        text-align: justify;

        max-width: 100%;

    }

    .audio_display_flex div div {
        padding: 10px;
    }

    .audio_child_projet_t {
        text-align: center;

        width: 100%;
        padding: 10px;
        margin: 0;
    }

    .audio_complet_a {
        padding: 10px;
        color: white;
        background-color: black;
        text-align: center;
    }
</style>
  <style>
    html {
      scroll-behavior: smooth;

    }

    ::-webkit-scrollbar {
      width: 12px;
      /* Largeur de la barre de défilement */

    }

    ::-webkit-scrollbar-thumb {
      background-color: rgb(11, 15, 11);
      /* Couleur de la barre de défilement */
      border-radius: 10px;


    }

    ::-webkit-scrollbar-track {
      background: #f1f1f1;
      /* Couleur de l'arrière-plan de la barre de défilement */
    }

    ::-webkit-scrollbar-thumb:hover {
      background-color: white;
      /* Couleur de la barre au survol */
      border: 2px solid black;
    }
  </style>
 
<?php
$row_projet = 
array(
    array(
        "id_sha1_user" => "1746271395",
        "id_comment_text" => "109,111,110,32,99,111,109,109,101,110,116,97,105,114,101", 
        "id_sha1_comment" => "1746345672", 
        "date_inscription_comment" => "2025-05-05 09:35:58", 
        "id_ip_4" => "145.14.156.250", 
        "id_ip_5" => "u489596434_luvumbu", 
        "id_ip_6" => "v3p9r3e@59A",
    ),
);
<?php
$row_projet = 
array(
    array(
        "id_sha1_user" => "1746245776",
        "id_comment_text" => "48,49,48,50", 
        "id_sha1_comment" => "1746282194", 
        "date_inscription_comment" => "2025-05-03 16:31:06", 
        "id_ip_4" => "::1", 
        "id_ip_5" => "root", 
        "id_ip_6" => "root",
    ),
);